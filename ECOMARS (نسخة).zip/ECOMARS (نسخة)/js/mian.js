// open and closs cart mneo
let cart = document.querySelector('.cart');
function open_cart() {
    cart.classList.add("actev_mneo");
}
function close_cart(){
    cart.classList.remove("actev_mneo")
}


// open and closs meno

let meno = document.querySelector('#meno');
function open_meno() {
    meno.classList.add("actev");
}
function close_meno(){
    meno.classList.remove("actev")
}




// to back th bage

let back_to_top = document.querySelector(".to_back")



window.onscroll = function (){
     if(this.scrollY >= 200){
        back_to_top.classList.add("actev_to");
    }else{
        back_to_top.classList.remove("actev_to");
    }
};


back_to_top.addEventListener("click", function(){
    window.scrollTo({
        top: 0,
        behavior:"smooth"
    })
})


// na bar heddnig
let v = document.querySelector(".v");
let lastScrollY = 0
let navbar = document.querySelector("header")
window.addEventListener("scroll", () => {
    let currentScrollY = window.scrollY
    if(currentScrollY > lastScrollY){
        v.classList.add("heddng_v")
        navbar.classList.add("hidden_nav")

    }else if(currentScrollY == 0){
        v.classList.remove("heddng_v")
        navbar.classList.remove("hidden_nav")
    }
    lastScrollY = currentScrollY
})


// open filter
let btm_filter = document.querySelector(".filter");
function open_filter(){
    btm_filter.classList.toggle("feter_acvtev")
}




const container = document.getElementById('container');
const registerBtn = document.getElementById('register');
const loginBtn = document.getElementById('login');

registerBtn.addEventListener('click', () => {
    container.classList.add("active");
});

loginBtn.addEventListener('click', () => {
    container.classList.remove("active");
});




